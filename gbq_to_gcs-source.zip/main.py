import functions_framework
from google.cloud import bigquery
from datetime import datetime
from google.oauth2 import service_account
from google.cloud import secretmanager
import json

#Function to get the secret value from secret manager service in GCP by passing the secret_id and project_id
def access_secret_version(project_id, secret_id, version_id='latest'):

    #SecretManagerServiceClient-Used to make requests to the Secret Manager API.
    client = secretmanager.SecretManagerServiceClient()

    # Build the secret version name.
    name = f"projects/{project_id}/secrets/{secret_id}/versions/{version_id}"

    # This triggers a request to Secret Manager to retrieve the details of the specified version of the secret.
    response = client.access_secret_version(name=name)

    #This extracts the payload (the actual secret data) from the response using response.payload.data. 
    #The payload is then decoded as UTF-8 to convert it from bytes to a string.
    payload = response.payload.data.decode('UTF-8')

    return payload


# CloudEvent function to be triggered by an Eventarc Cloud Audit Logging trigger
# Note: this is NOT designed for second-party (Cloud Audit Logs -> Pub/Sub) triggers!
@functions_framework.cloud_event
def hello_auditlog(cloudevent):
 
    # Print out details from the `protoPayload`
    # This field encapsulates a Cloud Audit Logging entry
    # See https://cloud.google.com/logging/docs/audit#audit_log_entry_structure
 
    payload = cloudevent.data.get("protoPayload")
     
    if payload:   
      # Timestamp in string format
      now = datetime.now()
      timestamp = now.strftime("%Y%m%d%H%M")

      bucket_name = 'gcp-dev-03'
      project = "hidden-mapper-414810"
      secret_id = "service_account_json_key"
      dataset_id = "insertjobdataset"
      table_id = "etlauditlog"

      #Calling the function to retrieve the secret value
      secret_value = access_secret_version(project, secret_id)
     
      #The value returned from the function is string, but service_account_info function expects dictionary-like object
      service_account_info = json.loads(secret_value)

      #Configuring the credential with the json key retrieved from above steps
      credentials = service_account.Credentials.from_service_account_info(service_account_info,scopes=["https://www.googleapis.com/auth/bigquery"])

      #Construct a BigQuery client object.
      client = bigquery.Client(credentials=credentials, project=project)

      #Set the destination uri
      destination_uri = "gs://{}/{}".format(bucket_name, "table_to_bucket_extract_" + timestamp + ".csv")

      #query to extract data from table
      query = "select * from " + project + "." + dataset_id + "." + table_id

      #saving the results of the query to a DataFrame 
      df_query_result = client.query(query).to_dataframe()

      #Write object to a comma-separated values (csv) file.
      df_query_result.to_csv(destination_uri)


     