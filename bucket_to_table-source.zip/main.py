import functions_framework

import pandas as pd
from google.cloud import bigquery



def hello_gcs(event, context):
    """Triggered by a change to a Cloud Storage bucket.
    Args:
         event (dict): Event payload.
         context (google.cloud.functions.Context): Metadata for the event.
    """

    #Python client to our BigQuery instance
    client = bigquery.Client()

    lst = []
    file_name = event['name']
    table_name = file_name.split('.')[0]
    project_id = 'hidden-mapper-414810'
    dataset_id = 'cloud_function'
    #writing metadata details into Big Query
    dct={
         'Event_ID':context.event_id,
         'Event_type':context.event_type,
         'Bucket_name':event['bucket'],
         'File_name':event['name'],
         'Created':event['timeCreated'],
         'Updated':event['updated']
        }
    lst.append(dct)
    
    #creating dataframe object from list of dictionary.
    df_metadata = pd.DataFrame.from_records(lst)
    
    #Configuration options for load jobs.
    #write_disposition - Describes whether a job should overwrite or append the existing destination table if it already exists.
    job_config = bigquery.LoadJobConfig(write_disposition = "WRITE_APPEND")
    
    #Load contents of a pandas DataFrame to a table.
    job = client.load_table_from_dataframe(df_metadata,"{}.{}.{}".format(project_id,dataset_id,'metadata_info'),job_config=job_config)

    
    #Reading the csv file and putting it into a dataframe.
    df_data = pd.read_csv('gs://' + event['bucket'] + '/' + file_name)
    
    #Load contents of a pandas DataFrame to a table.
    job = client.load_table_from_dataframe(df_data,"{}.{}.{}".format(project_id,dataset_id,table_name),job_config=job_config)
